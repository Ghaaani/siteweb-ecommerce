<?php

use Illuminate\Support\Facades\Route;

use App\Http\Controllers\indexController;
use App\Http\Controllers\shopController;
use App\Http\Controllers\Controller;
use App\Http\Controllers\ProductController;
use App\Http\Controllers\product_categoryController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Route::resource('/product_categories' , product_categoryController::class);
Route::resource('/products', ProductController::class);


Route::get('/index', [indexController::class,'index']);

Route::get('/shop/get-products-by-category/{categoryId}', [shopController::class, 'getProductsByCategory']);

Route::get('/shop', [shopController::class,'index']);



Route::get('/about', function () {
    return view('about');
});

Route::get('/cart', function () {
    return view('cart');
});

Route::get('/contact', function () {
    return view('contact');
});

Route::get('/checkout', function () {
    return view('checkout');
});

Route::get('/wishlist', function () {
    return view('wishlist');
});

Route::get('/single_product', function () {
    return view('single-product');
});

Route::get('/single_blog', function () {
    return view('single-blog');
});

Route::post('/filter-products', 'ProductController@filterProducts')->name('filter.products');
